#include <iostream>
#include <cstdint>
#include <iomanip>

uint32_t expand_2bit_to_bytes(uint8_t x) {
    uint32_t result = 0;
    for (int i = 0; i < 4; ++i) {
        uint8_t two_bits = (x >> (i * 2)) & 0x03;
        result |= static_cast<uint32_t>(two_bits) << (i * 8);
    }
    return result;
}

int main() {
    std::cout << "const uint32_t lut[256] = {\n";

    for (int i = 0; i < 256; ++i) {
        uint32_t val = expand_2bit_to_bytes(static_cast<uint8_t>(i));
        std::cout << "    0x" << std::hex << std::setw(8) << std::setfill('0') << val;

        if (i < 255)
            std::cout << ",";
        if ((i + 1) % 8 == 0)
            std::cout << "\n";
        else
            std::cout << " ";
    }

    std::cout << "};\n";
    return 0;
}
